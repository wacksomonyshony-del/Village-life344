# Village Evolution (Forge 1.21.1)

A civilization-simulation mod for villages: they detect themselves, track
population/housing/resources/stats, automatically decide what to build
next, and villagers actually gather materials, deliver them, and construct
the buildings themselves. On top of that, villagers heal iron golems,
blacksmiths specialize in golem repair, and clerics treat the wounded.

## Feature checklist

**Village civilization**
- Village detection/persistence — `VillageSavedData` / `VillagerJoinHandler`
- Development levels 0-5 (Camp → Hamlet → Village → Town → City → Metropolis) — `VillageStage`
- Population tracking — `VillageInstance.population`, refreshed every growth tick
- Housing tracking — `VillageInstance.housingCapacity`, summed from HOUSE buildings
- Food/resource tracking — `ResourceType` (WOOD/STONE/IRON/FOOD) pools per village
- Village statistics — `VillageStatistics` (buildings built/upgraded, projects completed, villagers healed, golems repaired, materials gathered, food produced)
- Village projects — `ConstructionProject` (gathering phase → building phase)
- Automatic expansion — `VillageManager.considerNewProject` / `decideNextBuilding`
- Building upgrades — `ConstructionProject(upgrade=true)` + `VillageBuilding.setLevel`
- Town → City progression — part of the 0-5 `VillageStage` ladder

**Advanced villagers**
- Individual tasks — `VillagerTaskData` (IDLE/GATHER/DELIVER/BUILD), persisted per-villager
- Gather construction materials — `GatherMaterialsGoal`
- Deliver materials — `DeliverMaterialsGoal`
- Participate in construction — `ConstructionWorkGoal`
- Recognize village needs — `VillageManager.decideNextBuilding` (priority-ordered needs analysis)
- Profession-specific responsibilities — farmers contribute food (`FarmerContributeFoodGoal`), clerics heal (`HealWoundedVillagerGoal`), blacksmith-professions specialize in golem repair (`RepairIronGolemGoal`)
- Injured-villager health state — `VillagerInjuryHelper` (severity scoring + periodic visual cue)
- Clerics heal injured villagers — `HealWoundedVillagerGoal`, prioritizes the most critical patient
- Villagers repair damaged iron golems — `RepairIronGolemGoal`
- Blacksmiths specialize in golem repairs — same goal, `isBlacksmithProfession()` gives armorers/weaponsmiths/toolsmiths faster + stronger + longer-range repairs

**Buildings** (`BuildingType`, laid out procedurally by `BlueprintLibrary`, no external schematic files needed)
- House, Farm, Storage, Market, Blacksmith, Town Hall, Clinic, Hospital, Watchtower, Wall & Gate
- Each scales in footprint/height/materials with level — e.g. a level-1 House is a small planked hut, a level-3 House is a bigger cobblestone-accented multi-bed home; Watchtowers get taller per level; Walls get longer

**Creative tab + items**
- "Village Evolution" creative tab (`ModCreativeTab`) containing one Blueprint item per building type
- Each item has its own generated 16x16 sprite (parchment/scroll base + building-specific glyph + color accent) under `assets/villageevolution/textures/item/`
- Right-clicking a blueprint item queues that building's construction (or upgrade, if one already exists) in the nearest village, gated by population/stage requirements — villagers then have to actually gather materials and build it

## How it all fits together (runtime flow)

1. `VillagerJoinHandler` registers a village near any villager and attaches goals to it.
2. Every 5 seconds, `VillageManager.tickProjects` looks at the village: if it has no active project, `decideNextBuilding` picks the next priority (Town Hall first, then houses if overpopulated, then farms, then everything else in unlock order), and queues a `ConstructionProject`. It then assigns idle nearby villagers as gatherers or builders.
3. Assigned villagers run `GatherMaterialsGoal` (mine a matching block: logs/stone/ore) → `DeliverMaterialsGoal` (walk it back, deposit into the project) in a loop until the project has all its materials, then `ConstructionWorkGoal` (stand at the site, accumulate labor) until it's finished.
4. `VillageManager.completeProject` places the building via `BlueprintLibrary`, registers/upgrades it on the village, and updates statistics.
5. Every 5 minutes, `VillageManager.tickGrowth` re-counts population, consumes food, adds growth points, and advances the village's `VillageStage` once it has enough growth *and* enough buildings.
6. Independently: any villager runs `RepairIronGolemGoal` on wounded golems (blacksmiths do it better); clerics run `HealWoundedVillagerGoal` on the most critically wounded villager nearby; farmers periodically deposit harvested crops into the village's food stock via `FarmerContributeFoodGoal`.

## Tuning

- `VillageStage` — `growthRequired` per stage.
- `BuildingType` — `minPopulation`, `minStage`, `housingPerLevel`, resource costs, ideal worker counts.
- `VillageManager` — `SEARCH_RADIUS`, `GROWTH_INTERVAL_TICKS`, `PROJECT_INTERVAL_TICKS`.
- `ConstructionProject.LABOR_REQUIRED` — how long the building phase takes.
- `BlueprintLibrary` — edit any building's generator method to change its shape/materials.
- Goal classes (`RepairIronGolemGoal`, `HealWoundedVillagerGoal`, etc.) — heal amounts, intervals, search radii.

## Building

Requires JDK 21 and network access (Gradle needs to pull Forge + MDK
dependencies on first run).

```
./gradlew build          # produces build/libs/villageevolution-1.0.0.jar
./gradlew runClient      # launch a dev client with the mod loaded
```

**Before building**, check `gradle.properties` — `forge_version` may need
bumping to whatever the latest 1.21.1 build is at
https://files.minecraftforge.net/net/minecraftforge/forge/index_1.21.1.html

## Honest scope notes

This is a large, from-scratch simulation written directly against the
1.21.1 Mojang-mapped API without a live compiler available in this
environment (no network access here to pull Gradle/Forge dependencies).
The architecture and the large majority of API calls should be correct,
but a few things worth knowing:

- **Buildings are procedurally generated**, not loaded from hand-made NBT
  structure files. This keeps the whole mod self-contained in source and
  means every building type has 2-3 tiers, but they're simple geometric
  layouts (boxes, farms, towers) rather than hand-crafted schematics. Feel
  free to swap `BlueprintLibrary`'s generators for real `.nbt` structure
  templates later if you want more detailed builds.
- **Construction is abstracted**, not literal block-by-block placement
  while workers watch — materials are gathered/delivered visibly, and
  workers visibly travel to and "work" the site with particles/sounds, but
  the finished building appears all at once when the project completes.
  Doing true incremental block-by-block construction from vanilla-only
  entities would need custom rendering/scaffolding beyond a single mod
  build.
- A couple of API spots are flagged in code comments (`VillagerJoinHandler`,
  `VillageSavedData`) where Mojang has changed method signatures across
  recent versions (e.g. `VillagerProfession` potentially being
  Holder-wrapped, `SavedData`'s registry-context parameters) — if you hit a
  compile error there, the comment tells you the one-line fix to try.
- Villager individual task state persists via the entity's vanilla
  "persistent data" tag; active *construction projects* themselves are
  kept in memory only (not written to disk) for simplicity, so a server
  restart mid-project loses that project's progress (completed buildings
  and village stats are never lost — those persist fine).
